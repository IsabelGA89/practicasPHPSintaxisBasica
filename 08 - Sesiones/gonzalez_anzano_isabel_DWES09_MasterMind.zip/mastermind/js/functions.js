function cambia_color(n) {
    var color = document.getElementById(n).value;
    var elemento = document.getElementById(n);
    elemento.className = color;
}


